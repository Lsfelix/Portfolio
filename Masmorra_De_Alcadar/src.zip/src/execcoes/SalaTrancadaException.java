package execcoes;

public class SalaTrancadaException extends RuntimeException {
	public SalaTrancadaException() {
	}
}
