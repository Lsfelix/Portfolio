package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Circulo extends Ferramenta {

	public Circulo() {
		super("CIRCULO", new Image("file:circulo.png", 60, 60, true, true));
	}

}
