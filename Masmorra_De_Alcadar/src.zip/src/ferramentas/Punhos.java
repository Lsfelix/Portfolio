package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Punhos extends Ferramenta {

	public Punhos() {
		super("PUNHOS", new Image("file:punhos.png", 60, 60, true, true));
		// TODO Auto-generated constructor stub
	}

}
