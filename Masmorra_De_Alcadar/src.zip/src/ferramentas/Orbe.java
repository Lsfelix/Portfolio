package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Orbe extends Ferramenta {

	public Orbe() {
		super("ORBE", new Image("file:orbe.png", 60, 60, true, true));
		// TODO Auto-generated constructor stub
	}

}
