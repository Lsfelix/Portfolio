package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Triangulo extends Ferramenta {

	public Triangulo() {
		super("TRIANGULO", new Image("file:triangulo.png", 60, 60, true, true));
	}

}
