package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Espada extends Ferramenta {

	public Espada() {
		super("ESPADA", new Image("file:espada.png", 60, 60, true, true));
		// TODO Auto-generated constructor stub
	}

}
