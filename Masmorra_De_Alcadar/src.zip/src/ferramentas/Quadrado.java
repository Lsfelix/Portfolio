package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Quadrado extends Ferramenta {

	public Quadrado() {
		super("QUADRADO", new Image("file:quadrado.png", 60, 60, true, true));
	}

}
