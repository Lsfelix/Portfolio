package ferramentas;

import ClassesBasicas.Ferramenta;
import javafx.scene.image.Image;

public class Marreta extends Ferramenta {

	public Marreta() {
		super("MARRETA", new Image("file:martelo.png", 60, 60, true, true));
		// TODO Auto-generated constructor stub
	}

}
